# Pyarmor 9.2.7 (basic), 009868, 2026-09-22T08:26:35.668735
from .pyarmor_runtime import __pyarmor__
