# Pyarmor 9.2.7 (basic), 009868, 2026-09-27T22:29:39.452581
from .pyarmor_runtime import __pyarmor__
