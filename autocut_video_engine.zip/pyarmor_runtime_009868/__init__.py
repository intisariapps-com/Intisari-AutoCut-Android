# Pyarmor 9.2.3 (basic), 009868, 2026-09-19T21:39:57.870903
from .pyarmor_runtime import __pyarmor__
