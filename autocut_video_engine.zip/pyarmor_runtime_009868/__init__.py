# Pyarmor 9.2.7 (basic), 009868, 2026-09-25T21:57:02.451550
from .pyarmor_runtime import __pyarmor__
