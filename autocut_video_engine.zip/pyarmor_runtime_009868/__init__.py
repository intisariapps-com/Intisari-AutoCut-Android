# Pyarmor 9.2.7 (basic), 009868, 2026-09-21T15:32:02.729230
from .pyarmor_runtime import __pyarmor__
