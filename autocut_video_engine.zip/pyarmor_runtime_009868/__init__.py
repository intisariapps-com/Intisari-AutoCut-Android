# Pyarmor 9.2.7 (basic), 009868, 2026-10-20T23:42:14.879549
from .pyarmor_runtime import __pyarmor__
