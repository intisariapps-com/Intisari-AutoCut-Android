# Pyarmor 9.2.7 (basic), 009868, 2026-10-20T20:48:31.164434
from .pyarmor_runtime import __pyarmor__
