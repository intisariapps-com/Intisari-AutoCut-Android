# Pyarmor 9.2.7 (basic), 009868, 2026-09-27T19:28:18.634267
from .pyarmor_runtime import __pyarmor__
