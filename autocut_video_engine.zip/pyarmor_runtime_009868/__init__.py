# Pyarmor 9.2.7 (basic), 009868, 2026-09-22T22:25:25.724568
from .pyarmor_runtime import __pyarmor__
