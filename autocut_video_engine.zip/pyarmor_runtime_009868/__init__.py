# Pyarmor 9.2.7 (basic), 009868, 2026-09-24T14:42:07.953125
from .pyarmor_runtime import __pyarmor__
