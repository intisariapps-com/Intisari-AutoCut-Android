# Pyarmor 9.2.7 (basic), 009868, 2026-09-29T13:54:00.659249
from .pyarmor_runtime import __pyarmor__
