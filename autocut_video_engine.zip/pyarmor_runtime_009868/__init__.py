# Pyarmor 9.2.7 (basic), 009868, 2026-09-20T01:50:54.374216
from .pyarmor_runtime import __pyarmor__
