# Pyarmor 9.2.7 (basic), 009868, 2026-09-27T15:18:42.811763
from .pyarmor_runtime import __pyarmor__
