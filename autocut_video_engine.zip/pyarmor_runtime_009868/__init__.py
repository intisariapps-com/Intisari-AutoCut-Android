# Pyarmor 9.2.7 (basic), 009868, 2026-09-22T10:22:06.327300
from .pyarmor_runtime import __pyarmor__
