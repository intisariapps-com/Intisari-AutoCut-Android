# Pyarmor 9.2.7 (basic), 009868, 2026-09-23T11:19:58.043943
from .pyarmor_runtime import __pyarmor__
